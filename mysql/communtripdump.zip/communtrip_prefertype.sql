-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: communtrip
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `prefertype`
--

DROP TABLE IF EXISTS `prefertype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prefertype` (
  `type` varchar(50) NOT NULL,
  `typename` varchar(20) NOT NULL,
  `image` varchar(200) NOT NULL,
  `title` varchar(100) NOT NULL,
  `addr1` varchar(100) NOT NULL,
  `latitude` decimal(20,17) DEFAULT NULL,
  `longitude` decimal(20,17) DEFAULT NULL,
  PRIMARY KEY (`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefertype`
--

LOCK TABLES `prefertype` WRITE;
/*!40000 ALTER TABLE `prefertype` DISABLE KEYS */;
INSERT INTO `prefertype` VALUES ('hiker3','한사랑산악회','http://tong.visitkorea.or.kr/cms/resource/00/1961100_image2_1.jpg','가야산(서산)','충청남도 서산시 해미면 산수리',36.70398643000000000,126.60910600000000000),('paragliding6','인싸이드','http://tong.visitkorea.or.kr/cms/resource/86/1900086_image2_1.jpg','가평TOP랜드 번지점프','경기도 가평군 가평읍 북한강변로 1044-15',37.80603914000000000,127.52600310000000000),('mountain-home3','피톤치드중독자','http://tong.visitkorea.or.kr/cms/resource/76/2007476_image2_1.JPG','계룡산글램핑','충청남도 공주시 반포면 계룡대로 1352',36.35606543000000000,127.25347960000000000),('paragliding6','인싸이드','http://tong.visitkorea.or.kr/cms/resource/57/2722657_image2_1.jpg','곤지암 루지 360도','경기도 광주시 도척면 도척윗로 278',37.33748369000000000,127.29222400000000000),('hotel5','게으른베짱이','http://tong.visitkorea.or.kr/cms/resource/42/1378142_image2_1.jpg','그랜드 하얏트 인천','인천광역시 중구 영종해안남로321번길 208',37.44044023000000000,126.45744430000000000),('white-sand-beach4','심해어','http://tong.visitkorea.or.kr/cms/resource/72/221572_image2_1.jpg','김녕성세기해변 (김녕해수욕장)','제주특별자치도 제주시 구좌읍 구좌해안로 237',33.55667783000000000,126.75964850000000000),('paragliding6','인싸이드','http://tong.visitkorea.or.kr/cms/resource/04/2014004_image2_1.jpg','단양드림레저 패러글라이딩','충청북도 단양군 수변로 59-1 롯데게스트하우스',36.98092801000000000,128.37048160000000000),('waterfalls4','물아일체','http://tong.visitkorea.or.kr/cms/resource/28/1135528_image2_1.jpg','담터계곡','강원도 철원군 동송읍',38.15617821000000000,127.18859870000000000),('mountain-home3','피톤치드중독자','http://tong.visitkorea.or.kr/cms/resource/74/2792874_image2_1.jpg','대봉산자연휴양림','경상남도 함양군 병곡면 병곡지곡로 333',35.57798159000000000,127.71504830000000000),('fun5','MZ세대','http://tong.visitkorea.or.kr/cms/resource/20/2824920_image2_1.JPG','대한민국와인축제','충청북도 영동군 영동힐링로 117',36.15639773000000000,127.78653190000000000),('hotel5','게으른베짱이','http://tong.visitkorea.or.kr/cms/resource/56/2607356_image2_1.png','롯데호텔서울','서울특별시 중구 을지로 30 롯데호텔',37.56540165000000000,126.98104580000000000),('white-sand-beach4','심해어','http://tong.visitkorea.or.kr/cms/resource/35/2653435_image2_1.jpg','만리포해수욕장','충청남도 태안군 소원면 만리포2길 138',36.78580232000000000,126.14226840000000000),('waterfalls4','물아일체','http://tong.visitkorea.or.kr/cms/resource/77/1602677_image2_1.jpg','명대골계곡','충청남도 보령시 청라면 장현리',36.45016121000000000,126.67510680000000000),('hiker3','한사랑산악회','http://tong.visitkorea.or.kr/cms/resource/50/2675750_image2_1.jpg','보문산 행복 숲 둘레길','대전광역시 중구 대사동 197-208',36.30926822000000000,127.42224360000000000),('fun5','MZ세대','http://tong.visitkorea.or.kr/cms/resource/96/2830696_image2_1.jpg','부산불꽃축제','부산광역시 수영구 광안해변로 219',35.15379084000000000,129.11849220000000000),('koreanstyle-house6','애국자','http://tong.visitkorea.or.kr/cms/resource/06/2512006_image2_1.jpg','북촌한옥마을','서울특별시 종로구 계동길 37',37.57916125000000000,126.98642550000000000),('hiker3','한사랑산악회','http://tong.visitkorea.or.kr/cms/resource/45/2526645_image2_1.jpg','북한산국립공원(서울)','서울특별시 성북구 보국문로 262',37.62154536000000000,126.99432640000000000),('koreanstyle-house6','애국자','http://tong.visitkorea.or.kr/cms/resource/49/2816649_image2_1.jpg','서산해미읍성축제','충청남도 서산시 남문2로 143 해미읍성',36.71360375000000000,126.55039440000000000),('hotel5','게으른베짱이','http://tong.visitkorea.or.kr/cms/resource/14/1358914_image2_1.jpg','서울 선샤인호텔','서울특별시 강남구 도산대로 205',37.52062715000000000,127.02878720000000000),('hotel5','게으른베짱이','http://tong.visitkorea.or.kr/cms/resource/45/1903045_image2_1.jpg','서울신라호텔','서울특별시 중구 동호로 249',37.55593373000000000,127.00516890000000000),('hiker3','한사랑산악회','http://tong.visitkorea.or.kr/cms/resource/43/780843_image2_1.jpg','설악산국립공원(내설악)','강원도 인제군 북면',38.12473146000000000,128.20415960000000000),('mountain-home3','피톤치드중독자','http://tong.visitkorea.or.kr/cms/resource/04/2677704_image2_1.jpg','속리산국립공원(충북)','충청북도 보은군 법주사로 84 속리산국립공원관리사무소',36.51738483000000000,127.81721920000000000),('white-sand-beach4','심해어','http://tong.visitkorea.or.kr/cms/resource/63/2733163_image2_1.jpg','속초해수욕장','강원도 속초시 해오름로 190',38.19057591000000000,128.60199360000000000),('koreanstyle-house6','애국자','http://tong.visitkorea.or.kr/cms/resource/26/1947026_image2_1.jpg','스미스가 좋아하는 한옥','서울특별시 종로구 삼청로 22-7',37.57803072000000000,126.98004830000000000),('waterfalls4','물아일체','http://tong.visitkorea.or.kr/cms/resource/47/2393447_image2_1.jpg','아침가리계곡','강원도 인제군 기린면 추대길 58',37.96544817000000000,128.39931070000000000),('waterfalls4','물아일체','http://tong.visitkorea.or.kr/cms/resource/83/1617283_image2_1.jpg','안덕계곡','제주특별자치도 서귀포시 안덕면 서안골로',33.25619622000000000,126.35162410000000000),('koreanstyle-house6','애국자','http://tong.visitkorea.or.kr/cms/resource/46/2827646_image2_1.png','여수 거북선축제','전라남도 여수시 이순신광장로 146',34.73732666000000000,127.73972630000000000),('fun5','MZ세대','http://tong.visitkorea.or.kr/cms/resource/07/2717307_image2_1.jpg','완주 프러포즈축제','전라북도 완주군 구이면 덕천전원길 232-58',35.72606023000000000,127.13617900000000000),('waterfalls4','물아일체','http://tong.visitkorea.or.kr/cms/resource/25/194825_image2_1.jpg','용수골계곡','강원도 원주시 판부면',37.27977444000000000,127.93897270000000000),('mountain-home3','피톤치드중독자','http://tong.visitkorea.or.kr/cms/resource/50/2661750_image2_1.jpg','장태산자연휴양림','대전광역시 서구 장안로 461',36.21595800000000000,127.34127560000000000),('koreanstyle-house6','애국자','http://tong.visitkorea.or.kr/cms/resource/34/2426934_image2_1.jpg','전주한옥레일바이크','전라북도 전주시 덕진구 동부대로 420',35.82969081000000000,127.17610050000000000),('fun5','MZ세대','http://tong.visitkorea.or.kr/cms/resource/47/2689747_image2_1.png','제25회 보령머드축제','충청남도 보령시 신흑동',36.31484622000000000,126.51511090000000000),('fun5','MZ세대','http://tong.visitkorea.or.kr/cms/resource/89/2539389_image2_1.JPG','제주 유채꽃축제','제주특별자치도 서귀포시 녹산로 381-17',33.38347715000000000,126.73566850000000000),('paragliding6','인싸이드','http://tong.visitkorea.or.kr/cms/resource/63/1930963_image2_1.jpg','제주해양레저','제주특별자치도 서귀포시 중문관광로 192',33.24325982000000000,126.41901300000000000),('paragliding6','인싸이드','http://tong.visitkorea.or.kr/cms/resource/63/2755163_image2_1.jpg','조이다이브 스쿠버다이빙','제주특별자치도 서귀포시 중산간동로 8383',33.26084561000000000,126.52125930000000000),('hotel5','게으른베짱이','http://tong.visitkorea.or.kr/cms/resource/37/1347837_image2_1.jpg','파라다이스호텔 부산','부산광역시 해운대구 해운대해변로 296',35.15994099000000000,129.16412140000000000),('mountain-home3','피톤치드중독자','http://tong.visitkorea.or.kr/cms/resource/32/1919432_image2_1.jpg','팔봉산(서산)','충청남도 서산시 팔봉면 양길리',36.80423751000000000,126.37535780000000000),('white-sand-beach4','심해어','http://tong.visitkorea.or.kr/cms/resource/49/176449_image2_1.jpg','풍류해수욕장','전남 고흥군 두원면 풍류리',34.66395670000000000,127.22931720000000000),('hiker3','한사랑산악회','http://tong.visitkorea.or.kr/cms/resource/60/601660_image2_1.jpg','한라산 트레킹','제주특별자치도 제주시 1100로 2070-61',33.39273062000000000,126.49487250000000000),('white-sand-beach4','심해어','http://tong.visitkorea.or.kr/cms/resource/67/2612467_image2_1.jpg','해운대해수욕장','부산광역시 해운대구 해운대해변로 264',35.15912435000000000,129.16030790000000000);
/*!40000 ALTER TABLE `prefertype` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-25 10:28:59
